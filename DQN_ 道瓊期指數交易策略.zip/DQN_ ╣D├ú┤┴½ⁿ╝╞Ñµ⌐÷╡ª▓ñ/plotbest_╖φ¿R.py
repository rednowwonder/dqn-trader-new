# -*- coding: utf-8 -*-
"""
Created on Sun Jan 10 21:48:59 2021

@author: user
"""

import torch
import numpy as np
from pandas import Series,DataFrame
import pandas as pd
from tqdm import trange
import math
from matplotlib import pyplot as plt
from agent2 import ValidationAgent
from function import getStockDataVec, getState, formatPrice


window_size = 20
stockname = 'DJI_2007'
agent = ValidationAgent(window_size,220,True)#,True
#print(agent.policy_net)
data = getStockDataVec(stockname,'all')
dataclose = data[3]
dataopen = data[0]
l = len(dataclose)
#batch_size = 32
state = getState(data, window_size + 1, window_size + 1)
total_profit = 0
agent.inventory = []
buys = window_size*[None]
sells = window_size*[None]
capital = 100000
tradenum = 0
actionlist = (window_size - 1)*[5]

for t in trange(window_size, l):
    reward = 0
    action = agent.act(state) 
    actionlist.append(action)
    if actionlist[t-1] == 0: # buy
        buys.append(dataopen[t])
        sells.append(dataclose[t])
        reward = dataclose[t] - dataopen[t] -2
        total_profit += reward
        tradenum += 1

    elif actionlist[t-1] == 1: # sell
        buys.append(dataopen[t])
        sells.append(dataclose[t])
        reward = dataopen[t] - dataclose[t] -2 #手續費
        total_profit += reward
        tradenum += 1
    elif actionlist[t-1] == 5:
        buys.append(None)
        sells.append(None)

    next_state = getState(data, t + 1, window_size + 1)
    done = True if t == l - 1 else False
    agent.memory.push(state, action, next_state, reward)
    state = next_state


    if done:
        print("--------------------------------")
        print(f'第{220}次')
        print(stockname + " Total Profit: " + formatPrice(total_profit))
        print('交易次數 : ' + str(tradenum))
        print("--------------------------------")
        print(actionlist.count(0),actionlist.count(1))
        sss = {
              'closes': Series(dataclose),
                 'action': Series(actionlist),
                 'buys' : Series(buys),
                 'sells': Series(sells)
             }


sss = DataFrame(sss)
# =============================================================================
# dateid = []
# lines = open("data/" + stockname + ".csv", "r").read().splitlines()
# for line in lines[1:]:
#     close = line.split(",")[4]
#     if close != 'null':
#         dateid.append(line.split(",")[0])
# 
# buyin = [None]
# sellin = [None]
# buyout = [None]
# sellout = [None]
# totalreturn = 0
# totalreturnlist = [0]
# for i in range(1,len(sss)):
#     if sss.loc[i-1,'action'] == 0:
#         buyin.append(sss.loc[i,'buys'])
#         sellout.append(sss.loc[i,'sells'])
#         sellin.append(None)
#         buyout.append(None)
#         totalreturn += sss.loc[i,'sells'] - sss.loc[i,'buys'] -2
#     if sss.loc[i-1,'action'] == 1:
#         sellin.append(sss.loc[i,'buys'])
#         buyout.append(sss.loc[i,'sells'])
#         buyin.append(None)
#         sellout.append(None)
#         totalreturn += sss.loc[i,'buys'] - sss.loc[i,'sells'] -2
#     if sss.loc[i-1,'action'] == 5:
#         sellin.append(None)
#         buyout.append(None)
#         buyin.append(None)
#         sellout.append(None)
#     totalreturnlist.append(totalreturn)
#     
# df =  DataFrame({'date' : dateid,'DJI_closes' : dataclose,'totalreturn' : totalreturnlist})
# df = df.set_index('date')
# df.plot(grid=1,figsize=(12,9),title='Dow Jones Index')
# #df['closes'].plot(grid=1,figsize=(12,9),title=f'{stockname} index')
# #df['totalreturn'].plot(grid=1,figsize=(12,9))
# plt.axvline(x=math.ceil(len(dataclose)*0.6), ymin=0, ymax=1, color = 'red')
# plt.axvline(x=math.ceil(len(dataclose)*0.8), ymin=0, ymax=1, color = 'red')
# plt.show()
# 
# =============================================================================
signal = 20*[5]
for i in range(len(sss)):
    if sss.loc[i,'buys'] > sss.loc[i,'sells']:
        signal.append(0)
    if sss.loc[i,'buys'] == sss.loc[i,'sells']:
        signal.append(3)
    if sss.loc[i,'buys'] < sss.loc[i,'sells']:
        signal.append(1)
sss['signal'] = signal
sss['shiftaction'] = sss['action'].shift(1)

precisiondf = sss.iloc[20:,-2:].reset_index(drop = True)
a = []
correct = 0
false = 0
equal = 0
for i in range(len(precisiondf)):
    if precisiondf.loc[i,'signal'] == 1:
        if precisiondf.loc[i,'shiftaction'] == 1:
            a.append('Correct')
        else:
            a.append('False')
    if precisiondf.loc[i,'signal'] == 0:
        if precisiondf.loc[i,'shiftaction'] == 0:
            a.append('Correct')
        else:
            a.append('False')
    if precisiondf.loc[i,'signal'] == 3:
        a.append('Equal')
precisiondf['compare'] = a
compareprecision = DataFrame(columns=['Correct', 'False','Equal'],index=['train','valid','test'])
aa = precisiondf['compare'][:math.ceil(len(precisiondf)*0.6)].value_counts()
bb = precisiondf['compare'][math.ceil(len(precisiondf)*0.6):math.ceil(len(precisiondf)*0.8)].value_counts()
cc = precisiondf['compare'][math.ceil(len(precisiondf)*0.8):].value_counts()
compareprecision['Correct'] = [aa['Correct'],bb['Correct'],cc['Correct']]
compareprecision['False'] = [aa['False'],bb['False'],cc['False']]
compareprecision['Equal'] = [aa['Equal'],bb['Equal'],cc['Equal']]
compareprecision['Precision'] = (compareprecision['Correct'] + compareprecision['Equal'])/(compareprecision['Correct'] + compareprecision['False'] + compareprecision['Equal'])   

buyin = [None]
sellin = [None]
buyout = [None]
sellout = [None]
totalreturn = 0
totalreturnlist = [0]
for i in range(1,len(sss)):
    if sss.loc[i-1,'action'] == 0:
        buyin.append(sss.loc[i,'buys'])
        sellout.append(sss.loc[i,'sells'])
        sellin.append(None)
        buyout.append(None)
        totalreturn += sss.loc[i,'sells'] - sss.loc[i,'buys'] -2
    if sss.loc[i-1,'action'] == 1:
        sellin.append(sss.loc[i,'buys'])
        buyout.append(sss.loc[i,'sells'])
        buyin.append(None)
        sellout.append(None)
        totalreturn += sss.loc[i,'buys'] - sss.loc[i,'sells'] -2
    if sss.loc[i-1,'action'] == 5:
        sellin.append(None)
        buyout.append(None)
        buyin.append(None)
        sellout.append(None)
    totalreturnlist.append(totalreturn)

#績效比較表
comparereturn = DataFrame(columns=['Dow Jones Index', 'DQN model return'],index=['train','valid','test'])
comparereturn.loc['train','DQN model return'] = totalreturnlist[math.ceil(len(totalreturnlist)*0.6)]
comparereturn.loc['valid','DQN model return'] = totalreturnlist[math.ceil(len(totalreturnlist)*0.8)] - totalreturnlist[math.ceil(len(totalreturnlist)*0.6)]
comparereturn.loc['test','DQN model return'] = totalreturnlist[-1] - totalreturnlist[math.ceil(len(totalreturnlist)*0.8)]
comparereturn.loc['train','Dow Jones Index'] = dataclose[math.ceil(len(dataclose)*0.6)] - dataclose[0]
comparereturn.loc['valid','Dow Jones Index'] = dataclose[math.ceil(len(dataclose)*0.8)] - dataclose[math.ceil(len(dataclose)*0.6)]
comparereturn.loc['test','Dow Jones Index'] = dataclose[-1] - dataclose[math.ceil(len(dataclose)*0.8)]
comparereturn['DQN Model Profit'] = comparereturn['DQN model return']*20
summary = pd.concat([compareprecision,comparereturn],axis = 1)

