# -*- coding: utf-8 -*-
"""
Created on Mon Jan 11 23:33:36 2021

@author: user
"""

import torch
import numpy as np
from pandas import Series,DataFrame
import pandas as pd
from tqdm import trange
import math
from matplotlib import pyplot as plt
from agent2 import ValidationAgent
from function import getStockDataVec, getState, formatPrice


window_size = 20
stockname = 'DJI_2007'
agent = ValidationAgent(window_size,433,True)#,True
#print(agent.policy_net)
data = getStockDataVec(stockname,'all')
dataclose = data[3]
dataopen = data[0]
l = len(dataclose)
#batch_size = 32
state = getState(data, window_size + 1, window_size + 1)
total_profit = 0
agent.inventory = []
buys = window_size*[None]
sells = window_size*[None]
capital = 100000
tradenum = 0
actionlist = (window_size - 1)*[5]

for t in trange(window_size, l):
    reward = 0
    action = agent.act(state) 
    actionlist.append(action)

    if actionlist[t-1] == 0 and len(agent.inventory) == 0: # buy
        #print("Buy: " + formatPrice(dataopen[t]))
        if capital > dataopen[t]:
            agent.inventory.append(dataopen[t])
            buys.append(dataopen[t])
            sells.append(None)
            capital -= dataopen[t]
        else:
            buys.append(None)
            sells.append(None)

    elif actionlist[t-1] == 1: # sell
        if len(agent.inventory) > 0:
            bought_price = agent.inventory.pop(0)
            reward = dataopen[t] - bought_price - 2 #手續費
            total_profit += reward
            buys.append(None)
            sells.append(dataopen[t])
            capital += dataopen[t]
            #print("Sell: " + formatPrice(dataopen[t]) + " | Profit: " + formatPrice(dataopen[t] - bought_price))
            tradenum += 1
        else:
            buys.append(None)
            sells.append(None)
    elif actionlist[t-1] == 0:
        buys.append(None)
        sells.append(None)
    else:
        buys.append(None)
        sells.append(None)


    next_state = getState(data, t + 1, window_size + 1)
    done = True if t == l - 1 else False
    agent.memory.push(state, action, next_state, reward)
    state = next_state


    if done:
        print("--------------------------------")
        print('第433次')
        print(stockname + " Total Profit: " + formatPrice(total_profit))
        print('交易次數 : ' + str(tradenum))
        print("--------------------------------")
        print(actionlist.count(0),actionlist.count(1))

sss = {
    'closes': Series(dataclose),
    'buys' : Series(buys),
    'sells': Series(sells)
    }
sss = pd.concat([DataFrame(sss).iloc[:,:2].fillna(method='pad',axis=0),DataFrame(sss).iloc[:,-1]],axis=1)
sssnull = sss.isnull()
dateid = []
lines = open("data/" + stockname + ".csv", "r").read().splitlines()
for line in lines[1:]:
    close = line.split(",")[4]
    if close != 'null':
        dateid.append(line.split(",")[0])
totalrewardlist = []
totalreward = 0
for i in range(len(sss)):
    reward = 0
    if sssnull.iloc[i,1] == True and sssnull.iloc[i,2] == True:
        totalreward += 0
    if sssnull.iloc[i,1] != True and sssnull.iloc[i,2] == True:
        reward = sss.iloc[i,0] - sss.iloc[i,1]
    if sssnull.iloc[i,1] != True and sssnull.iloc[i,2] != True:
        totalreward += sss.iloc[i,2] - sss.iloc[i,1] - 2
    totalrewardlist.append(totalreward + reward)
    
df =  DataFrame({'date' : dateid,'closes' : dataclose,'totalreturn' : totalrewardlist})
df = df.set_index('date')
df.plot(grid=1,figsize=(12,9),title='Dow Jones Index')
#df['closes'].plot(grid=1,figsize=(12,9),title='Dow Jones Index')
#df['totalreturn'].plot(grid=1,figsize=(12,9))
plt.axvline(x=math.ceil(len(dataclose)*0.6), ymin=0, ymax=1, color = 'red')
plt.axvline(x=math.ceil(len(dataclose)*0.8), ymin=0, ymax=1, color = 'red')
plt.show()

sss['return'] = sss['sells']-sss['buys']
ss = sss.iloc[20:,:].reset_index(drop = True)
ss['true'] = ss['return'].isnull()
train,valid,test= [],[],[]
for i in range(math.ceil(len(ss)*0.6)):
    if ss.iloc[i,:]['true'] == False:
        train.append(ss.iloc[i,:]['return'])
for i in range(math.ceil(len(ss)*0.6),math.ceil(len(ss)*0.8)):
    if ss.iloc[i,:]['true'] == False:
        valid.append(ss.iloc[i,:]['return'])
for i in range(math.ceil(len(ss)*0.8),len(ss)):
    if ss.iloc[i,:]['true'] == False:
        test.append(ss.iloc[i,:]['return'])

train1,valid1,test1,train2,valid2,test2= [],[],[],[],[],[]

for i in train:
    train1.append(i) if i>= 0 else train2.append(i)
for i in valid:
    valid1.append(i) if i>= 0 else valid2.append(i)
for i in test:
    test1.append(i) if i>= 0 else test2.append(i)
#績效表現表
summary = DataFrame(columns=['Correct', 'False','Precision','Dow Jones Index','DQN Model Return','DQN Model Profit'],index=['train','valid','test'])
summary['Correct'] = [len(train1),len(valid1),len(test1)]
summary['False'] = [len(train2),len(valid2),len(test2)]
summary['Precision'] = summary['Correct']/(summary['Correct'] +summary['False'])
summary['Dow Jones Index'] = [5473,6718,5581]
summary['DQN Model Return'] = [sum(train),sum(valid),sum(test)]
summary['DQN Model Profit'] = summary['DQN Model Return']*20



